#ifndef CACHE_H
#define CACHE_H

#include "main.h"

class ReplacementPolicy {
    //TODO
};

class SearchEngine {
    //TODO
};

class MFU : public ReplacementPolicy {
    //TODO
};

class LFU : public ReplacementPolicy {
    //TODO
};
class MFRU: public ReplacementPolicy {
    //TODO
};

class LFRU: public ReplacementPolicy {
    //TODO
};

class BST : public SearchEngine {
    //TODO
};
#endif